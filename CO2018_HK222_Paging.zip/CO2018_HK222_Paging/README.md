# CO2018_HK222
CO2018 - Simple Operating System Assignment, including: 
- Scheduling 
- Memory
- Synchronization
- Report

Current LaTeX report [here](https://www.overleaf.com/read/vkgmzcqgtvbz)

## How to work within the repository 
- Clone the project [from here](https://github.com/Athenaxdd/CO2018_HK222): 

  > Or type this in the terminal: git clone https://github.com/Athenaxdd/CO2018_HK222
  
- Commit the changes: 
  > git add .

  > git commit -m "Your Message"
  
  > git pull (Make sure to pull before pushing to not losing progress)
  
  > git push origin main
  
  > Or use Github Desktop app
  

